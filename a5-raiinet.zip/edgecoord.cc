#include "edgecoord.h"

EdgeCoord::EdgeCoord(Coords coords, Player &owner, string displayName): SpecialCoord(coords, owner, displayName) {}
