#include "serverport.h"

ServerPort::ServerPort(Coords coords, Player &owner, string displayName): SpecialCoord(coords, owner, displayName) {}
